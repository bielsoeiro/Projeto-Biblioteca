
package operacoes;

import java.util.Arrays;

public class main {

    public static void main(String []args) {

        // Vetor original
        int[] numeros = {6, 3, 5, 1, 4, 2};

        // Copias para cada algoritmo
        int[] vetorBubble = numeros.clone();
        int[] vetorInsertion = numeros.clone();
        int[] vetorMerge = numeros.clone();


        // =================================
        //           BUBBLE SORT
        // =================================

        BubbleSort.ordenar(vetorBubble);

        System.out.println("===== BUBBLE SORT =====");
        System.out.println("Vetor: " + Arrays.toString(vetorBubble));
        System.out.println("Comparações: " + BubbleSort.comparacoes);
        System.out.println("Trocas: " + BubbleSort.trocas);
        System.out.println("Tempo: " + BubbleSort.tempoExecucao + " ns");


        // =================================
        //         INSERTION SORT
        // =================================

        InsertionSort.ordenar(vetorInsertion);

        System.out.println("\n===== INSERTION SORT =====");
        System.out.println("Vetor: " + Arrays.toString(vetorInsertion));
        System.out.println("Comparações: " + InsertionSort.comparacoes);
        System.out.println("Trocas: " + InsertionSort.movimentos);
        System.out.println("Tempo: " + InsertionSort.tempoExecucao + " ns");


        // =================================
        //           MERGE SORT
        // =================================

        MergeSort.ordenar(vetorMerge);

        System.out.println("\n===== MERGE SORT =====");
        System.out.println("Vetor: " + Arrays.toString(vetorMerge));
        System.out.println("Movimentações: " + MergeSort.movimentacoes);
        System.out.println("Tempo: " + MergeSort.tempoExecucao + " ns");

    }
}
