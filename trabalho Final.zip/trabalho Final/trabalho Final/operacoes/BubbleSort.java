
package operacoes;

public class BubbleSort {

    public static int comparacoes = 0;
    public static int trocas = 0;
    public static long tempoExecucao = 0;

    public static void ordenar(int[] numeros) {

        long inicio = System.nanoTime();

        comparacoes = 0;
        trocas = 0;

        //troca e comparações do Bubble Sort 
        for (int j = 0; j < numeros.length - 1; j++) {

            for (int i = 0; i < numeros.length - 1 - j; i++) {

                comparacoes++;

                //variavel temporaria para trocas 
                if (numeros[i] > numeros[i + 1]) {

                    int auxiliar = numeros[i];
                    numeros[i] = numeros[i + 1];
                    numeros[i + 1] = auxiliar;

                    trocas++;
                }
            }
        }
        long fim = System.nanoTime();
        tempoExecucao = fim - inicio;
    }
}
