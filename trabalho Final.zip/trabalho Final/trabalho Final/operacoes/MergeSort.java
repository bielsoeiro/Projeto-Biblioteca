
package operacoes;

public class MergeSort {

    // Contadores e tempo
    public static int movimentacoes = 0;
    public static long tempoExecucao = 0;

    // Método principal de ordenação
    public static void ordenar(int[] numeros) {

        movimentacoes = 0;

        long inicio = System.nanoTime();

        ordenarRecursivo(numeros);

        tempoExecucao = System.nanoTime() - inicio;
    }

    // Divide o vetor recursivamente
    private static void ordenarRecursivo(int[] numeros) {

        if (numeros.length < 2) {
            return;
        }

        // Encontra o meio
        int meio = numeros.length / 2;

        // Cria os vetores auxiliares
        int[] esquerda = new int[meio];
        int[] direita = new int[numeros.length - meio];

        // Copia os elementos para esquerda
        for (int i = 0; i < meio; i++) {
            esquerda[i] = numeros[i];
        }

        // Copia os elementos para direita
        for (int i = meio; i < numeros.length; i++) {
            direita[i - meio] = numeros[i];
        }

        // Continua dividindo
        ordenarRecursivo(esquerda);
        ordenarRecursivo(direita);

        // Junta os vetores ordenados
        intercalar(numeros, esquerda, direita);
    }

    // Intercala os elementos em ordem crescente
    public static void intercalar(
            int[] numeros,
            int[] esquerda,
            int[] direita) {

        int i = 0;
        int j = 0;
        int k = 0;

        // Compara os elementos das duas metades
        while (i < esquerda.length && j < direita.length) {

            if (esquerda[i] <= direita[j]) {

                numeros[k] = esquerda[i];
                i++;

            } else {

                numeros[k] = direita[j];
                j++;
            }

            k++;
            movimentacoes++;
        }

        // Copia os elementos restantes da esquerda
        while (i < esquerda.length) {

            numeros[k] = esquerda[i];

            i++;
            k++;
            movimentacoes++;
        }

        // Copia os elementos restantes da direita
        while (j < direita.length) {

            numeros[k] = direita[j];

            j++;
            k++;
            movimentacoes++;
        }
    }
}
