
package operacoes;

public class InsertionSort {

    public static int comparacoes = 0;
    public static int movimentos = 0;
    public static long tempoExecucao = 0;

    public static void ordenar(int[] numeros) {

            long inicio = System.nanoTime();

        comparacoes = 0;
        movimentos = 0;

        for (int i = 1; i < numeros.length; i++) {

            int temp = numeros[i];
            int j = i - 1;

            while (j >= 0) {

                comparacoes++;

                if (numeros[j] > temp) {

                    numeros[j + 1] = numeros[j];
                    j--;
                    movimentos++;

                } else {
                    break;
                }
            }

            numeros[j + 1] = temp;
            movimentos++;

            long fim = System.nanoTime();   
            tempoExecucao = fim - inicio;
        }
    }
}
